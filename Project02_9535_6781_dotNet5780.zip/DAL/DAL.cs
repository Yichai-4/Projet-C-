﻿using BE;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DAL
{
    public class DAL : Idal
    {
        public void AddGuestrequest(GuestRequest guestRequest)
        {
            throw new NotImplementedException();
        }

        public void AddHostingUnit(HostingUnit hostingUnit)
        {
            throw new NotImplementedException();
        }

        public void AddInvitation(Order order)
        {
            throw new NotImplementedException();
        }

        public void AddOrder(Order order)
        {
            throw new NotImplementedException();
        }

        public bool DeleteHostingUnit(int myhostingUnitKey)
        {
            throw new NotImplementedException();
        }

        public List<HostingUnit> GetListOfAllAccommodationUnits(List<HostingUnit> hostingUnits)
        {
            throw new NotImplementedException();
        }

        public List<BankBranch> GetListOfAllExistingBankBranches(List<BankBranch> bankBranches)
        {
            throw new NotImplementedException();
        }

        public List<Order> GetListOfAllInvitations(List<Order> orders)
        {
            throw new NotImplementedException();
        }

        public void GuestrequestUpdate(GuestRequest guestRequest)
        {
            throw new NotImplementedException();
        }

        public void HostingUnitUpdate(HostingUnit hostingUnit)
        {
            throw new NotImplementedException();
        }

        public List<GuestRequest> ListAllCustomerRequirements(List<GuestRequest> guestRequests)
        {
            throw new NotImplementedException();
        }

        public void UpdateInvitation(Order order)
        {
            throw new NotImplementedException();
        }

        public void UpdateOrder(Order order)
        {
            throw new NotImplementedException();
        }
    }
}
