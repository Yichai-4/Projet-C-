﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using BE;

namespace DS
{
    public class DataSource
    {
        public static List<HostingUnit> lhostingUnits = new List<HostingUnit>();
        public static List<GuestRequest> lguestRequests = new List<GuestRequest>();
        public static List<Order> lorders = new List<Order>();
        public static List<BankBranch> lbankBranches = new List<BankBranch>();
    }
    public class DS
    {
    }
}
