﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using BE;


namespace BE
{
    public static class Configuration
    {
        public static int code = 100000000;

        public static int key = 100000000;

        public static int key1 = 100000000;

    }
}
